var p=0//用于保存car的位移变量
var q=0//用于保存canvase的位移变量
var i=0//用于判断是否可以继续点击左右标签
var k=0 //用于canvas遍历与存值
var q=15//用于canvas中的上下
var zb=0 //用于canvas中判断是否可以继续点击左右标签
var sskv=0//用于从ssskarr中作为下标
var text //用于作为在canvas轴上的文字的暂存变量
var ssskarr=["2018","韩城","扎鲁特","南溪","2017","厦门","韩城","青藏高原","环塔","南溪","2016","柳城","包头","武清","南溪","2015","甘肃","环塔","柳州","厦门","锡林浩特","长白山","晋城"]//建立一个数组，用于在canvas中标值
//点击左
$("#prev").click(function(){if(i>0){  p += 481;i--}
    $("#sslb_hx>ul").css("margin-left",`${p}px`)
})
//点击右
$("#next").click(function(e){if(i!=5){ p -= 481;i++}
    $("#sslb_hx>ul").css("margin-left",`${p}px`)
})
//画布时间轴
var skz1=document.getElementById("skz1")
var ctx=skz1.getContext("2d")
ctx.strokeStyle="white"
ctx.font="12px 宋体 lighter"
for(k=0;k<780;k=k+35) {
    ctx.save();
    ctx.beginPath()
    ctx.moveTo(0, 35)
    ctx.lineTo(k, 35)
    ctx.stroke()
    ctx.restore();
    ctx.lineTo(k,35+q)
    ctx.stroke()
    q=-q
    text= ssskarr[sskv]
    ctx.strokeText(text,k,35-q)
    sskv+=1

}

$("#zb_left").click(function(){
    console.log("1")
    if(zb>0){  q += 35;zb--}
    $("#skz1").css("margin-left",`${q}px`)

})
$("#zb_right").click(function(){
    if(zb!=7){  q -= 35;zb++}
    $("#skz1").css("margin-left",`${q}px`)
})
